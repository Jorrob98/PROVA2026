package it.jorrob.patentetab;

import android.app.*;
import android.content.*;
import android.content.pm.*;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.widget.Toast;
import androidx.core.content.FileProvider;
import org.json.JSONObject;
import java.io.*;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Locale;
import javax.net.ssl.HttpsURLConnection;

final class TabletUpdates {
 private static final String BASE="https://raw.githubusercontent.com/Jorrob98/PROVA2026/main/patente-studio-android/";
 private static final long MAX=50L*1024*1024;
 private final Activity a;private boolean busy; private volatile boolean closed, cancelled;private ProgressDialog progress;private File pending;
 TabletUpdates(Activity a){this.a=a;}
 private PackageInfo installed() throws Exception{return a.getPackageManager().getPackageInfo(a.getPackageName(),PackageManager.GET_SIGNATURES);}
 String version(){try{return installed().versionName;}catch(Exception e){return "1.0.2";}}
 private void ui(Runnable r){a.runOnUiThread(()->{if(!closed&&!a.isFinishing())r.run();});}
 private HttpsURLConnection get(String path)throws Exception{HttpsURLConnection c=(HttpsURLConnection)new URL(BASE+path).openConnection();c.setInstanceFollowRedirects(false);c.setConnectTimeout(12000);c.setReadTimeout(25000);c.setUseCaches(false);c.setRequestProperty("Cache-Control","no-cache");if(c.getResponseCode()!=200){c.disconnect();throw new IOException("Download non disponibile");}return c;}
 private JSONObject manifest()throws Exception{HttpsURLConnection c=get("android-update.json");try(InputStream in=c.getInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] b=new byte[2048];int n;while((n=in.read(b))!=-1){if(out.size()+n>16384)throw new IOException("Indice non valido");out.write(b,0,n);}return new JSONObject(out.toString("UTF-8"));}finally{c.disconnect();}}
 void check(){check(false,()->true);}
 void check(boolean silent,java.util.function.BooleanSupplier available){if(busy||closed)return;busy=true;if(!silent){progress=new ProgressDialog(a);progress.setMessage("Controllo aggiornamenti su GitHub…");progress.setCancelable(false);progress.show();}new Thread(()->{try{JSONObject m=manifest();int code=m.getInt("versionCode");String v=m.getString("version"),name=m.getString("file"),sha=m.getString("sha256");long size=m.getLong("size");if(!v.matches("[0-9]+\\.[0-9]+\\.[0-9]+")||!name.equals("PatenteStudio-Tablet-"+v+".apk")||!sha.matches("[a-fA-F0-9]{64}")||size<1||size>MAX)throw new IOException("Indice aggiornamenti non valido");int current=installed().versionCode;ui(()->{dismiss();busy=false;if(!available.getAsBoolean())return;if(code<=current){if(!silent)message("Patente Studio", "Hai già l'ultima versione ("+version()+").");return;}new AlertDialog.Builder(a).setTitle("Aggiornamento "+v).setMessage("Scarica e installa la nuova versione. Le postazioni memorizzate restano disponibili.").setNegativeButton("Annulla",null).setPositiveButton("Installa",(d,w)->download(v,name,sha,size,code)).show();});}catch(Exception e){if(silent)ui(()->{dismiss();busy=false;});else fail("Controllo non riuscito. Verifica la connessione Internet.");}}).start();}
 private void download(String v,String name,String sha,long size,int code){if(busy||closed)return;busy=true;cancelled=false;progress=new ProgressDialog(a);progress.setTitle("Aggiornamento "+v);progress.setMessage("Download in corso…");progress.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);progress.setMax(100);progress.setCancelable(false);progress.setButton(DialogInterface.BUTTON_NEGATIVE,"Annulla",(d,w)->cancelled=true);progress.show();new Thread(()->{File f=null;try{File dir=new File(a.getCacheDir(),"updates");if(!dir.exists()&&!dir.mkdirs())throw new IOException("Cache non disponibile");f=new File(dir,"update.apk");if(f.exists()&&!f.delete())throw new IOException("File occupato");MessageDigest digest=MessageDigest.getInstance("SHA-256");long total=0;HttpsURLConnection c=get(name);try(InputStream in=c.getInputStream();OutputStream out=new FileOutputStream(f)){byte[] b=new byte[32768];int n;while((n=in.read(b))!=-1){total+=n;if(total>size||closed||cancelled)throw new IOException("Download interrotto");digest.update(b,0,n);out.write(b,0,n);final long count=total;ui(()->{if(progress!=null){progress.setProgress((int)(100*count/size));progress.setMessage(String.format(Locale.ITALY,"Scaricati %.2f / %.2f MB",count/1048576d,size/1048576d));}});}}finally{c.disconnect();}if(cancelled||closed)throw new IOException("Download interrotto");if(total!=size||!hex(digest.digest()).equalsIgnoreCase(sha))throw new SecurityException("Impronta non corrispondente");ui(()->{if(progress!=null)progress.setMessage("Verifica firma applicazione…");});PackageInfo p=a.getPackageManager().getPackageArchiveInfo(f.getAbsolutePath(),PackageManager.GET_SIGNATURES);PackageInfo old=installed();if(p==null||!a.getPackageName().equals(p.packageName)||p.versionCode!=code||p.versionCode<=old.versionCode||p.signatures==null||old.signatures==null||!Arrays.equals(p.signatures,old.signatures))throw new SecurityException("Firma o versione non valida");final File apk=f;ui(()->{dismiss();busy=false;if(cancelled){apk.delete();return;}pending=apk;install();});}catch(Exception e){if(f!=null)f.delete();if(cancelled)ui(()->{dismiss();busy=false;});else fail(e instanceof SecurityException?"Aggiornamento non autentico o danneggiato: installazione bloccata.":"Download non riuscito. Riprova.");}}).start();}
 private static String hex(byte[] b){StringBuilder s=new StringBuilder();for(byte x:b)s.append(String.format(Locale.ROOT,"%02x",x&255));return s.toString();}
 private boolean waitingPermission=false;
 private void install(){if(pending==null||!pending.isFile())return;if(Build.VERSION.SDK_INT>=26&&!a.getPackageManager().canRequestPackageInstalls()){new AlertDialog.Builder(a).setTitle("Autorizza aggiornamenti").setMessage("Android richiede di autorizzare Patente Studio come fonte di installazione. Attiva il permesso e torna all'app.").setNegativeButton("Annulla",(d,w)->{pending.delete();pending=null;}).setPositiveButton("Impostazioni",(d,w)->{try{waitingPermission=true;a.startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,Uri.parse("package:"+a.getPackageName())));}catch(Exception e){waitingPermission=false;message("Aggiornamento","Impossibile aprire le impostazioni.");}}).show();return;}try{Uri uri=FileProvider.getUriForFile(a,a.getPackageName()+".files",pending);Intent i=new Intent(Intent.ACTION_VIEW).setDataAndType(uri,"application/vnd.android.package-archive").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);a.startActivity(i);}catch(Exception e){message("Aggiornamento","Installatore Android non disponibile.");}}
 void resume(){if(waitingPermission){waitingPermission=false;if(a.getPackageManager().canRequestPackageInstalls())install();else message("Aggiornamento","Autorizzazione non concessa. Puoi riprovare dal menu.");}}
 private void dismiss(){if(progress!=null){progress.dismiss();progress=null;}}
 private void message(String title,String content){new AlertDialog.Builder(a).setTitle(title).setMessage(content).setPositiveButton("OK",null).show();}
 private void fail(String m){ui(()->{dismiss();busy=false;message("Aggiornamento",m);});}
 void close(){closed=true;cancelled=true;dismiss();}
}
